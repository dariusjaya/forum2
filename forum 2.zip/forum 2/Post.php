<?php

namespace App\Models;



class Post
{
    private static $blog_posts =
    [
        [
            "title" => "Dota 2",
            "slug" => "judul-post-pertama",
            "author" => "Valve Corporation",
            "body" => "Dota 2 is a 2013 multiplayer online battle arena video game developed and published by Valve.
            The game is a sequel to Defense of the Ancients, which was a community-created mod for Blizzard Entertainment's Warcraft III: Reign of Chaos"

        ],
        [
            "title" => "Valorant",
            "slug"=> "judul-post-kedua",
            "author" => "Riot Games",
            "body" => "Valorant is a free-to-play first-person hero shooter developed and published by Riot Games, for Microsoft Windows.
            Teased under the codename Project A in October 2019, the game began a closed beta period with limited access on April 7, 2020, followed by a release on June 2, 2020."
        ],
    ];


    public static function all()
    {
        return collect(self::$blog_posts);
    }

    public static function find($slug)
    {
        $posts = static::all();


        return $posts->firstWhere('slug', $slug);
    }

}
