@extends('layouts.main')

@section('container')
        <h1>Home</h1>
        <h5>Info game terkini mengenai game favorit </h5>
        <h6>-Dota 2</h6>
        <img src="img/dota 2.jpg" alt="dota 2">
        <h6>-Valorant</h6>
        <img src="img/valorant.jpg" alt="valorant">

@endsection


